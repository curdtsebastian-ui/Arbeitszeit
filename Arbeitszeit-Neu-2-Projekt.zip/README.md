# Arbeitszeiterfassung 2

Neue, eigenständige Version. Neue applicationId: `ch.arbeitszeit.app.neu2`.

Kernregeln:
- Überzeitkonto basiert auf dem Wochen-Soll; keine künstliche Überzeit durch Nachtzuschlag.
- Nachtarbeit erzeugt separat 10 % Zeitgutschrift.
- Feiertage und entschuldigte Abwesenheiten reduzieren die Sollzeit.
- Ferien werden pro Kalenderjahr geführt.
- Arbeitsintervalle können über Mitternacht gehen.
- Alle Daten bleiben lokal im Gerät.
